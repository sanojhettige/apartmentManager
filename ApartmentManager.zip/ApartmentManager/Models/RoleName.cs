﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApartmentManager.Models
{
    public static class RoleName
    {
        public const string Admin = "Admin";
        public const string ApartmentAdmin = "ApartmentAdmin";
        public const string FinanceManage = "FinanceManager";
    }
}